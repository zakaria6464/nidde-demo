# NIDDE — AG-05 API CONTRACT ARCHITECTURE

Project: NIDDE  
Phase: 00 — ARCHITECTURE  
Gate: AG-05 — API Contract Architecture  
Revision: V1.0.0  
Status: READY FOR VERIFICATION  
Implementation: LOCKED

## 1. Purpose

AG-05 defines the API contract rules required before implementation. It translates the approved domain and data ownership principles into a stable service boundary without prescribing framework-specific code.

This document is a design contract, not executable API code, an OpenAPI implementation, or a database migration.

## 2. Contract Principles

- APIs expose domain capabilities rather than unrestricted database operations.
- Every mutation has one authoritative domain owner.
- Authentication and authorization are enforced server-side.
- Client input is never authoritative for role, ownership, price, payment result, KYC decision, or lifecycle state.
- Business lifecycle changes use explicit commands/actions where a generic update could bypass invariants.
- Financial and externally retried side effects are idempotent.
- Responses expose the minimum data required by the caller.
- Internal database structure and provider-specific implementation details are not public API contracts.

## 3. Logical API Domains

The API is organized around these domains:

1. Identity and Accounts
2. Client, Artisan, and Company Profiles
3. Service Categories and Service Offerings
4. Service Requests
5. Offers
6. Service Lifecycle
7. Locations and Tracking
8. Conversations and Messages
9. Payments and Cash Transactions
10. Reviews
11. KYC
12. Notifications
13. Administration and Moderation
14. Operational Analytics

A domain owns its mutations. Cross-domain behavior is coordinated through approved application/domain boundaries rather than direct database writes.

## 4. Authentication and Authorization

Protected endpoints require an authenticated identity unless explicitly classified as public.

Authorization evaluates the authenticated identity, effective permissions, resource ownership or participant relationship, lifecycle state, and domain-specific eligibility.

Client-provided role claims and ownership identifiers must not be trusted without server-side verification.

## 5. Resource and Command Model

Use resource-oriented operations for ordinary retrieval and creation. Use explicit commands for business transitions that carry invariants.

Representative shapes include:

- `POST /requests`
- `GET /requests/{requestId}`
- `POST /requests/{requestId}/offers`
- `POST /requests/{requestId}/accept`
- `POST /services/{serviceId}/en-route`
- `POST /services/{serviceId}/arrive`
- `POST /services/{serviceId}/start`
- `POST /services/{serviceId}/complete`
- `POST /payments`
- `POST /payments/{paymentId}/confirm`
- `POST /reviews`

These are logical examples; final route syntax may be normalized during implementation without changing ownership or business rules.

## 6. Request and Offer Contracts

A Service Request is owned by the client domain context and may only be modified by authorized actors according to its lifecycle.

An Offer references an existing request and an eligible provider profile.

The API must enforce request existence, provider eligibility, lifecycle compatibility, duplicate-active-offer prevention, and uniqueness of the accepted offer.

Amounts, terms, eligibility, and state transitions are validated server-side.

## 7. Lifecycle Contract

The authoritative service lifecycle from AG-04 is:

`REQUESTED → ACCEPTED → EN_ROUTE → ARRIVED → IN_PROGRESS → COMPLETED`

Cancellation and error states are explicit and must not be represented by silently overwriting a normal state.

Every transition records previous state, new state, actor, timestamp, reason where required, and a correlation/reference identifier.

Clients cannot directly assign lifecycle state through a generic update endpoint.

## 8. Payment and Cash Contracts

Payment states must distinguish at least pending, successful, failed, cancelled, and rejected.

Electronic payment success is accepted only after validation at the approved payment integration boundary. A client request cannot declare an electronic payment successful.

Cash Transaction is a separate auditable record and must not be confused with electronic provider state.

Payment creation, confirmation, callback handling, and reconciliation must be idempotent where retries can create side effects.

## 9. Idempotency

Mutations involving payments, provider callbacks/webhooks, reconciliation, or other externally retried side effects must support idempotency.

An idempotency key is scoped sufficiently to prevent accidental collision between actors and operations.

A repeated valid request must not create duplicate financial or lifecycle effects.

## 10. Error Contract

APIs use a consistent machine-readable error envelope containing, where applicable:

- `code`
- `message`
- `details`
- `correlation_id`

Error responses must not expose stack traces, SQL errors, credentials, secrets, internal tokens, or sensitive KYC/payment information.

Recommended semantic categories include validation, authentication, authorization, not_found, conflict, lifecycle_conflict, rate_limited, dependency_failure, and internal_error.

## 11. Collections

Collection endpoints use bounded pagination with stable ordering.

Filtering and sorting are allowlisted. Arbitrary database expressions are never accepted from clients.

Pagination metadata must be sufficient for the selected pagination strategy without exposing internal database details.

## 12. Versioning

The public API must have an explicit versioning strategy before implementation. Breaking changes require a new version or a controlled compatibility/migration strategy.

Internal refactoring must not silently change an established public contract.

## 13. Observability

Mutating requests receive or propagate a correlation identifier.

Payment, KYC, lifecycle, moderation, and administrative operations require auditable records.

Logs must avoid unnecessary sensitive payloads.

## 14. Rate Limits and Abuse Controls

Authentication, public discovery, request creation, offer creation, messaging, payment operations, and KYC submission require appropriate server-side rate limiting and abuse controls.

Limits are operational/security controls, not client-side guarantees.

## 15. External Integration Boundary

External providers are isolated behind integration adapters.

External responses and callbacks are untrusted input until authenticated, validated, correlated, and normalized.

Provider identifiers never become the sole internal source of truth.

## 16. Contract Verification Before Unlock

Before implementation begins, the project must verify:

- every endpoint has an owning domain
- authorization requirements are mapped
- lifecycle commands are mapped
- payment and webhook boundaries are defined
- idempotency requirements are mapped
- error conventions are defined
- sensitive response fields are reviewed
- integration adapters are identified

AG-05 alone does not unlock implementation.
