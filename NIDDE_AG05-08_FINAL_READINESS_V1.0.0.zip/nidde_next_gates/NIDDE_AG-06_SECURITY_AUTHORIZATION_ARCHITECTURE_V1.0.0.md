# NIDDE — AG-06 SECURITY & AUTHORIZATION ARCHITECTURE

Project: NIDDE  
Phase: 00 — ARCHITECTURE  
Gate: AG-06 — Security & Authorization Architecture  
Revision: V1.0.0  
Status: READY FOR VERIFICATION  
Implementation: LOCKED

## 1. Purpose

AG-06 defines the security and authorization contract required before implementation. It protects the identity, marketplace, service lifecycle, messaging, payment, KYC, location, and administrative domains defined by AG-04 and exposed through AG-05.

This document is a security design contract, not production security code.

## 2. Security Principles

- Server-side authorization is authoritative.
- Least privilege is mandatory.
- Authentication and authorization are separate controls.
- Sensitive data is minimized and access-controlled.
- Secrets never belong in source control.
- External input and provider callbacks are untrusted until validated.
- Financial, KYC, administrative, and lifecycle-sensitive actions are auditable.
- No cross-domain direct database writes are permitted outside approved data-access boundaries.

## 3. Application Roles

The principal application roles are:

- Client
- Artisan
- Company
- Admin

Admin is the highest application authority, but administrative activity remains authenticated, authorized, auditable, and subject to deployment/operational controls.

The server derives effective permissions from trusted account state. Client-supplied role values are never authoritative.

## 4. Authorization Model

Authorization combines:

- authenticated identity
- effective role/permission
- resource ownership
- participant relationship
- lifecycle state
- domain eligibility
- administrative authority

Examples:

A Client may manage only resources they own and are permitted to mutate in the current state.

An Artisan or Company may access offers and service information only where the provider is an authorized participant.

Conversation access is restricted to authorized participants.

KYC information is restricted to the verification workflow and authorized reviewers.

Administrative operations require explicit Admin authority and audit records.

## 5. Identity and Account Security

The common User identity is separate from Client, Artisan, and Company profiles.

Authentication material must never be stored in plaintext.

Account status must be checked as part of protected access decisions.

Recovery, credential changes, and other sensitive identity operations require appropriate verification and auditability.

## 6. Data Classification

At minimum, data is classified as:

- Public
- Internal
- Sensitive
- Highly Sensitive

Highly sensitive information includes authentication material, KYC documents, payment credentials/tokens, and private personal information.

API responses must follow data minimization and caller-specific authorization.

## 7. Secrets Management

Production secrets are supplied through an approved secret-management mechanism.

Never commit passwords, private keys, payment secrets, webhook secrets, production credentials, or real KYC documents.

`.env.example` contains variable names and safe placeholders only.

## 8. KYC Security

KYC Case controls verification state. KYC Document contains metadata while sensitive document contents are stored through the approved secure storage/integration boundary.

Access must be authenticated, authorized, auditable, minimized, and retention-controlled.

Verification decisions are server-authoritative and must not be client-editable.

## 9. Payment Security

A client cannot set electronic payment status to successful.

Provider callbacks/webhooks must be authenticated or cryptographically verified where supported, correlated to the expected transaction, checked for replay, and processed idempotently.

Financial records remain auditable and reconcilable.

## 10. Administrative Security

Administrative actions capture actor, target, action, reason, relevant previous state, resulting state, timestamp, and correlation/reference information.

High-impact administrative controls may require additional operational safeguards defined by deployment policy.

## 11. Messaging Privacy

Users can access only conversations for which they are authorized participants.

Private message content is not exposed to unrelated domains or tools without an approved authorization path.

## 12. Location and Tracking Security

Location and tracking data are sensitive and purpose-limited.

Precision, retention, visibility, and access must follow the minimum-necessary principle.

Tracking data is not authoritative proof of payment or service completion.

## 13. Input and File Security

All external input requires schema validation, authorization, length/format constraints, safe parsing, and appropriate output handling.

File uploads require controlled type, size, storage, access, and malware/security controls appropriate to the deployment environment.

## 14. Abuse Protection

Appropriate rate limits, throttling, lockouts, anomaly controls, or anti-automation measures must be applied to authentication, discovery, messaging, offer creation, payments, KYC, and administrative endpoints.

## 15. Audit and Retention

Financial, KYC, administrative, and lifecycle-sensitive audit records are append-oriented and traceable.

Corrections preserve the original audit trail through an approved correction mechanism.

Retention is defined according to legal, business, and security requirements for each data class.

## 16. Security Verification Before Unlock

The project must verify:

- role boundaries are mapped
- ownership and participant rules are mapped
- sensitive data is classified
- secret handling is defined
- payment and KYC boundaries are protected
- administrative actions are auditable
- abuse controls are identified
- security-sensitive API operations have authorization requirements

Implementation remains LOCKED until the final readiness gate is approved.
