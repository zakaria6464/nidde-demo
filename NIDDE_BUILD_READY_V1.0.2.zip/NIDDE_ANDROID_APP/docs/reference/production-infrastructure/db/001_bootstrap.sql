CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS _nidde_infrastructure_meta (
 id boolean PRIMARY KEY DEFAULT TRUE,
 schema_version text NOT NULL,
 initialized_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO _nidde_infrastructure_meta(id,schema_version) VALUES(TRUE,'1.0.0') ON CONFLICT(id) DO NOTHING;
