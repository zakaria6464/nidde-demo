import http from 'node:http';
import crypto from 'node:crypto';
import pg from 'pg';

const { Pool } = pg;
const port = Number(process.env.PORT || 8080);
const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error('DATABASE_URL is required');
const pool = new Pool({ connectionString: databaseUrl, max: Number(process.env.DB_POOL_MAX || 10), ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : undefined });
const windowMs = Number(process.env.RATE_LIMIT_WINDOW_MS || 60000);
const max = Number(process.env.RATE_LIMIT_MAX || 120);
const hits = new Map();
function rid(req){const v=req.headers['x-request-id']; return typeof v==='string' && /^[A-Za-z0-9._:-]{1,100}$/.test(v) ? v : crypto.randomUUID();}
function limited(ip){const now=Date.now(); const x=hits.get(ip); if(!x || now-x.start>=windowMs){hits.set(ip,{start:now,n:1}); return false;} x.n++; return x.n>max;}
function send(res,status,body,id){res.statusCode=status;res.setHeader('content-type','application/json; charset=utf-8');res.setHeader('x-request-id',id);res.setHeader('x-content-type-options','nosniff');res.setHeader('x-frame-options','DENY');res.setHeader('referrer-policy','no-referrer');res.end(JSON.stringify(body));}
const server=http.createServer(async (req,res)=>{const id=rid(req); if(limited(req.socket.remoteAddress||'unknown')) return send(res,429,{error:'rate_limited'},id); try{
 if(req.method==='GET' && req.url==='/health'){return send(res,200,{status:'ok',service:'nidde-production-gateway',version:'1.0.0'},id)}
 if(req.method==='GET' && req.url==='/ready'){await pool.query('SELECT 1'); return send(res,200,{status:'ready',database:'ok'},id)}
 if(req.method==='GET' && req.url==='/version'){return send(res,200,{project:'NIDDE',infrastructure:'1.0.0'},id)}
 send(res,404,{error:'not_found'},id);
 }catch(e){console.error({requestId:id,error:e.message});send(res,503,{error:'service_unavailable'},id)}});
server.listen(port,'0.0.0.0',()=>console.log(`NIDDE gateway listening on ${port}`));
process.on('SIGTERM',async()=>{server.close();await pool.end();process.exit(0)});
