# NIDDE Android Test App

This is an Android wrapper around the existing NIDDE Web Demo asset. It is intended for pre-release testing only.

## Test credentials
Email: admin@nidde.test
Password: NiddeAdmin!2026#Test

## Build
Use GitHub Actions workflow `Build NIDDE APK` (manual `workflow_dispatch` or push to `main`).
The workflow produces `app/build/outputs/apk/debug/app-debug.apk` as a downloadable artifact.

## Truth status
This package is an Android project prepared for a real build. An APK is not claimed until the build succeeds and the artifact is verified.
