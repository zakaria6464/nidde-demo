# NIDDE 1.0.5 — GitHub Release Candidate

This release consolidates the current NIDDE prototype, reference backend, database schema and production-infrastructure reference into one repository.

## Fixed in 1.0.5
- GitHub Actions now validates Android `versionCode 4` correctly.
- Claims API now verifies that the caller owns or is assigned to the referenced request (admins are allowed).
- Android role selection no longer exposes Admin to non-admin accounts and prevents role switching after authentication.
- Repository ignore rules added to prevent local secrets/build artifacts from being committed.

## Verified locally
- Backend foundation: 4/4 tests pass.
- Production infrastructure static checks: PASS.
- Node syntax checks: PASS.
- No production secrets are stored in the repository.

## Important
This is a **GitHub Release Candidate**, not a claim of full production readiness. Payments, KYC provider integration, push notifications, live tracking/maps, messaging, ratings, full admin APIs and production backup/restore still require implementation and environment configuration.

The Android APK is built by the included GitHub Actions workflow.
