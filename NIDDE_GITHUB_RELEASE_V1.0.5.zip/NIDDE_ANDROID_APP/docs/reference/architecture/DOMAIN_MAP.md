# Domain Map — NIDDE 01–28

01 Foundation
02 Home / Categories (historical reference)
03 Request Experience
04 Worker Onboarding / Identity / KYC / Profile
05 Matching
06 Job / Service Lifecycle
07 Historical artifact not recovered in current workspace
08 Maps / Location (referenced by Foundation)
09 Historical artifact not recovered in current workspace
10 Admin / Operations Control Plane
11 Enterprise / Multi-Site
12 Notification / Communication Orchestration
13 Support / Complaints / Disputes
14 Security / Access Control / Audit
15 Notification / Communication Preferences
16 Analytics / Reporting
17 Service Catalog / Availability
18 Service Search / Discovery
19 Provider Profiles / Verification
20 Orders / Booking Lifecycle
21 Offers / Bidding
22 Payments / Wallet
23 Cross-NIDDE Integration / Reliability
24 Cross-NIDDE Security / Integrity / Audit
25 Data Governance / Privacy
26 Localization / Service Area / Operational Configuration
27 Observability / Monitoring / Telemetry
28 Performance / Capacity / Resilience

02/07/08/09 are historical recovery gaps, not permission to invent replacement domains.
