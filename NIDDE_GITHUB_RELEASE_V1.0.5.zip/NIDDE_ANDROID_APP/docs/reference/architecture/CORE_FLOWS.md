# Core Application Flows

## Client
Login → location → browse/search → request → matching/offers → choose worker → booking → tracking → service → completion → payment → rating → support/dispute.

## Worker
Register → identity/KYC → profile → services/areas/availability → requests → accept/offer → schedule → en route → arrival → service → completion → wallet/payment projection.

## Enterprise
Authenticate → organization/sites → operational configuration → requests → monitoring → reporting.

## Admin
RBAC → dashboard → users/workers → KYC → requests/jobs → payments/commissions → claims → messages → audit → configuration → reporting.

Each lifecycle has one authoritative domain owner; other domains consume events/projections.
