# System Boundaries

## Frontend
- Client application
- Worker application
- Enterprise portal
- Admin console

## Backend
A modular application/API layer containing the domains represented by NIDDE 01–28. Initial implementation should use explicit domain modules and stable contracts rather than copying every NIDDE into an independent production service.

## Data
A central transactional datastore is the initial source of truth. Analytics consumes controlled projections.

## External integration boundaries
Maps/location, push, SMS/email, KYC, payments, object storage, optional search/geocoding.

External providers remain adapters until actually connected and tested.
