# Initial Transactional Data Model

Identity: User, Role, Permission, Session, Device
Worker: WorkerProfile, WorkerVerification, WorkerDocument, WorkerService, WorkerArea, WorkerAvailability
Catalog: Category, Service, ServiceAvailabilityRule
Requests: ServiceRequest, RequestAttachment, MatchCandidate, MatchDecision, Offer, OfferRevision
Booking/Job: Order, Job, Schedule, JobStateTransition, JobTimeline, Cancellation, Dispute
Location: Location, ServiceArea, TrackingSession, LocationEvent
Money: Payment, PaymentAttempt, Wallet, WalletEntry, Commission, NegativeBalance, Refund
Communication: Conversation, Message, Notification, NotificationPreference
Trust: Claim, SupportCase, Review, ReviewMedia
Enterprise: Organization, Site, OrganizationMember, SiteAssignment
Governance: AuditEvent, SecurityEvent, DataAccessEvent, Consent, ExportRequest, RetentionPolicy
Analytics: KPIProjection, MetricPoint, Report, OperationalSnapshot

IDs are opaque/stable. Timestamps UTC. Money uses integer minor units plus currency.
