# Initial API Surface

Auth: /auth/register, /auth/login, /auth/refresh, /auth/logout
Profiles/KYC: /profiles/me, /workers/verification, /workers/:id
Catalog/Discovery: /categories, /services, /workers/search, /workers/nearby
Requests/Offers: /requests, /requests/:id, /requests/:id/offers, /offers/:id/accept
Orders/Jobs: /orders/:id, /jobs/:id/transition, /jobs/:id/cancel, /jobs/:id/complete
Tracking: /tracking/sessions, /tracking/sessions/:id/events
Payments: /payments, /payments/:id, /wallet, /wallet/ledger
Communication: /conversations, /conversations/:id/messages, /notifications, /notification-preferences
Support: /support/cases, /disputes
Admin: /admin/*
Enterprise: /enterprise/*

Production routes must be versioned and finalized before implementation.
