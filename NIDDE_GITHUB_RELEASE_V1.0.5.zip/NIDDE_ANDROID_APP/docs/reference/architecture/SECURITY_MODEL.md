# Security Baseline

RBAC; least privilege; server-side authorization; credential secrecy; session expiry/revocation; KYC access control; PII minimization/redaction; append-oriented audit; idempotent financial commands; explicit admin permissions; rate limits; upload validation/scanning.
