#!/bin/sh
set -eu
for f in client/index.html worker/index.html enterprise/index.html admin/index.html; do test -s "$f"; grep -q '<html' "$f"; done
echo 'PRODUCT SURFACE SMOKE TESTS: 4/4 PASS'
