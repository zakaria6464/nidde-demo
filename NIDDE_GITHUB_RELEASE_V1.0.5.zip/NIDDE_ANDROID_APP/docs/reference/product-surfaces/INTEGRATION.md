# Integration Contract
Client: request/status surface.
Worker: request/acceptance surface.
Enterprise: multi-site operational surface.
Admin: oversight surface.
Production authentication, API deployment and external providers remain unimplemented.
