# NIDDE Production Infrastructure V1.0.0

This package creates a production-shaped infrastructure baseline: PostgreSQL, a hardened HTTP gateway, and Caddy HTTPS termination. It does NOT fabricate third-party credentials and it does not claim that external providers are connected.

## Run
1. Copy `.env.example` to `.env` and replace secrets.
2. Set `NIDDE_DOMAIN` to a domain whose DNS A/AAAA records point to the host.
3. Run `docker compose up -d --build`.
4. Verify `/health` and `/ready` through the domain.
5. Back up PostgreSQL before production data is introduced.

## Remaining real-world blockers
- DNS/domain ownership and production host credentials.
- Real authentication provider account/keys.
- Real object storage account/keys.
- Real maps provider key.
- Real push/SMS provider credentials.
- Real KYC provider credentials and webhook endpoint.
- Real payment provider credentials and webhook endpoint.
- Mobile signing certificates and store accounts.
- Monitoring/alert destination credentials.

These cannot be truthfully created inside this workspace without the external accounts/credentials and are therefore left explicit rather than mocked.
