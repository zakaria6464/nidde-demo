#!/usr/bin/env sh
set -eu
node --check app/app.mjs
node -e "const fs=require('fs'); for (const f of ['docker-compose.yml','Dockerfile','caddy/Caddyfile','db/001_bootstrap.sql']) { if(!fs.existsSync(f)) process.exit(1); } console.log('NIDDE infrastructure static checks: PASS')"
