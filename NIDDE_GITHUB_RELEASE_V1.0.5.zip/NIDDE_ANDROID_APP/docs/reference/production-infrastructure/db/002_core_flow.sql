CREATE TABLE IF NOT EXISTS offers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id uuid NOT NULL REFERENCES service_requests(id) ON DELETE CASCADE,
  worker_id uuid NOT NULL REFERENCES users(id),
  price_cents integer NOT NULL CHECK (price_cents > 0),
  eta_minutes integer NOT NULL CHECK (eta_minutes > 0),
  status text NOT NULL CHECK (status IN ('PENDING','ACCEPTED','REJECTED','WITHDRAWN')) DEFAULT 'PENDING',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(request_id, worker_id)
);
CREATE INDEX IF NOT EXISTS idx_offers_request ON offers(request_id, created_at);
CREATE INDEX IF NOT EXISTS idx_offers_worker ON offers(worker_id, created_at DESC);

ALTER TABLE service_requests ADD COLUMN IF NOT EXISTS worker_id uuid REFERENCES users(id);
ALTER TABLE service_requests ADD COLUMN IF NOT EXISTS accepted_offer_id uuid REFERENCES offers(id);
CREATE INDEX IF NOT EXISTS idx_requests_worker_status ON service_requests(worker_id, status);
