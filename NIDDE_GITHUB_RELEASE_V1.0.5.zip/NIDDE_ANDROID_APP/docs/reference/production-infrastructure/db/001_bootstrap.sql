CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS _nidde_infrastructure_meta (
  id boolean PRIMARY KEY DEFAULT TRUE,
  schema_version text NOT NULL,
  initialized_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO _nidde_infrastructure_meta(id,schema_version) VALUES(TRUE,'1.0.2') ON CONFLICT(id) DO UPDATE SET schema_version=EXCLUDED.schema_version;

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL UNIQUE,
  password_hash text NOT NULL,
  password_salt text NOT NULL,
  role text NOT NULL CHECK (role IN ('client','worker','enterprise','admin')),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

CREATE TABLE IF NOT EXISTS service_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES users(id),
  service text NOT NULL,
  description text NOT NULL,
  location text NOT NULL,
  status text NOT NULL CHECK (status IN ('CREATED','MATCHED','ACCEPTED','EN_ROUTE','ARRIVED','IN_PROGRESS','COMPLETED','CANCELLED')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_requests_client_created ON service_requests(client_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_requests_status ON service_requests(status);

CREATE TABLE IF NOT EXISTS claims (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id uuid NOT NULL REFERENCES service_requests(id),
  opened_by uuid NOT NULL REFERENCES users(id),
  text text NOT NULL,
  status text NOT NULL CHECK (status IN ('OPEN','IN_REVIEW','RESOLVED','CLOSED')),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_claims_request ON claims(request_id);
