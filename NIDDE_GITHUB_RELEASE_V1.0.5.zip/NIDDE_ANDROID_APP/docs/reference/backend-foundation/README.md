# NIDDE Backend Foundation V1.0.0

Phase 2 of the NIDDE application: backend foundation only.

## Stack baseline
- Node.js + native ESM JavaScript
- HTTP API foundation using Node's built-in `http` module
- Environment-driven configuration
- Structured JSON errors
- Request/correlation IDs
- Health/readiness endpoints
- Modular domain boundary
- Node test runner

This is NOT a production backend yet. Database, authentication provider, queues, payments,
KYC, maps, notifications and deployment infrastructure remain explicit adapters for later phases.
