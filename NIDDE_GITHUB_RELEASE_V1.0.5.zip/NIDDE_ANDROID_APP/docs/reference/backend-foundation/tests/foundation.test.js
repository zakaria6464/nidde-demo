import test from 'node:test';
import assert from 'node:assert/strict';
import { loadConfig } from '../src/config/env.js';
import { createApp } from '../src/app.js';

async function request(app, method, url, headers={}) {
  const req = { method, url, headers };
  const out = { headers:{}, body:'' };
  const res = { statusCode:200, headers:{}, setHeader(k,v){this.headers[k]=v}, end(v){this.body=v} };
  await app(req,res); return {res, json:JSON.parse(res.body)};
}

test('config defaults and validation',()=>{
  assert.equal(loadConfig({}).port,3000);
  assert.throws(()=>loadConfig({PORT:'0'}));
});
test('health and readiness',async()=>{
  const app=createApp(loadConfig({}));
  const h=await request(app,'GET','/health'); assert.equal(h.res.statusCode,200); assert.equal(h.json.status,'ok');
  const r=await request(app,'GET','/ready'); assert.equal(r.json.status,'ready');
});
test('unknown route returns structured 404',async()=>{
  const app=createApp(loadConfig({})); const x=await request(app,'GET','/missing');
  assert.equal(x.res.statusCode,404); assert.equal(x.json.error.code,'NOT_FOUND'); assert.ok(x.json.error.requestId);
});
test('request id is propagated',async()=>{
  const app=createApp(loadConfig({})); const x=await request(app,'GET','/health',{'x-request-id':'test-id'});
  assert.equal(x.res.headers['x-request-id'],'test-id'); assert.equal(x.json.status,'ok');
});
