export class AppError extends Error {
  constructor(status, code, message) { super(message); this.status = status; this.code = code; }
}
export function errorPayload(err, requestId) {
  const known = err instanceof AppError;
  return { error: { code: known ? err.code : 'INTERNAL_ERROR', message: known ? err.message : 'Internal server error', requestId } };
}
