import { randomUUID } from 'node:crypto';
export function requestId(req) { return req.headers['x-request-id'] || randomUUID(); }
