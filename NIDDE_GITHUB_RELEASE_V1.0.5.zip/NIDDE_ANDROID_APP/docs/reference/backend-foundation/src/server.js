import { createServer } from 'node:http';
import { loadConfig } from './config/env.js';
import { createApp } from './app.js';
const config = loadConfig();
createServer(createApp(config)).listen(config.port, () => console.log(`${config.serviceName} listening on ${config.port}`));
