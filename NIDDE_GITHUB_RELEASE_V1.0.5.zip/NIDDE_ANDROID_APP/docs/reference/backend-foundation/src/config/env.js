export function loadConfig(env = process.env) {
  const port = Number(env.PORT || 3000);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('Invalid PORT');
  return Object.freeze({
    nodeEnv: env.NODE_ENV || 'development',
    port,
    serviceName: env.SERVICE_NAME || 'nidde-backend',
    apiVersion: env.API_VERSION || 'v1'
  });
}
