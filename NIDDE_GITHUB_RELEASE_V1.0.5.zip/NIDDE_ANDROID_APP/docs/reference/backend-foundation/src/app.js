import { Router } from './http/router.js';
import { requestId } from './core/request-context.js';
import { errorPayload } from './core/errors.js';

export function createApp(config) {
  const router = new Router();
  router.add('GET', '/health', async () => ({ status: 'ok', service: config.serviceName }));
  router.add('GET', '/ready', async () => ({ status: 'ready', service: config.serviceName }));
  router.add('GET', `/api/${config.apiVersion}`, async () => ({ status: 'ok', apiVersion: config.apiVersion }));

  return async function app(req, res) {
    const id = requestId(req);
    res.setHeader('content-type','application/json; charset=utf-8');
    res.setHeader('x-request-id', id);
    try {
      const url = new URL(req.url, 'http://localhost');
      const handler = router.match(req.method, url.pathname);
      if (!handler) { res.statusCode=404; res.end(JSON.stringify({error:{code:'NOT_FOUND',message:'Route not found',requestId:id}})); return; }
      const body = await handler({ req, requestId:id });
      res.statusCode=200; res.end(JSON.stringify(body));
    } catch (err) {
      const payload = errorPayload(err,id); res.statusCode = err?.status || 500; res.end(JSON.stringify(payload));
    }
  };
}
