export class Router {
  constructor(){ this.routes = new Map(); }
  add(method, path, handler){ this.routes.set(`${method.toUpperCase()} ${path}`, handler); }
  match(method, path){ return this.routes.get(`${method.toUpperCase()} ${path}`); }
}
