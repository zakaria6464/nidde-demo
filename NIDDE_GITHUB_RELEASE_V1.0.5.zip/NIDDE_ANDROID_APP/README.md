# NIDDE Unified Android App V1.0.2

This is the next Android integration point for NIDDE. It replaces the old single-screen Web Demo inside the Android WebView with a unified Client / Worker / Enterprise / Admin prototype and preserves the authoritative reference modules in `docs/reference/`.

## Included references
- Master application architecture
- Backend Foundation
- Core Vertical Slice
- Money & Trust
- Product Surfaces
- NIDDE 12 Notifications & Communication
- NIDDE 13 Support / Complaints / Disputes
- Production Infrastructure

## Important
This APK surface is a functional offline integration prototype. Production persistence, authentication providers, payment providers, push/SMS/email providers, maps/tracking providers, and deployment secrets must remain behind the documented integration boundaries.
