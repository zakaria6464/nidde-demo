# NIDDE Android Integration Audit V1.0.2

## Fixed
1. ZIP layout matches the existing GitHub extraction workflow: `NIDDE_ANDROID_APP/...`.
2. CI builds from the project root and verifies required Android files before Gradle execution.
3. Artifact path is `app/build/outputs/apk/debug/app-debug.apk`.
4. Removed unused Node.js runtime modules from Android assets. Their reference implementations remain under `docs/reference`.
5. Kept `applicationId=ma.nidde.demo` intentionally; changing it would create a different Android app identity.
6. Kept `INTERNET` permission because future API integration is an explicit boundary, but the prototype itself is local-only.
7. Added explicit Client/Worker/Enterprise/Admin prototype flows and state transitions without pretending backend persistence is live.

## Existing limitations intentionally not hidden
- Debug APK is not a production-signed release.
- Backend/provider integrations are not live in this APK.
- Demo counters are labeled as prototype UI and are not production telemetry.

## Expected build
Java 17 + Android SDK 35 + Build Tools 35.0.0 + Gradle 8.13 + Android Gradle Plugin 8.13.0.
