# Security Policy

NIDDE is currently in Phase 00 — Architecture.

Rules:
- Never commit passwords, API keys, tokens, private keys, or production credentials.
- Use `.env.example` only as a non-secret template.
- Security verification is mandatory before implementation registration.
- Do not publish sensitive vulnerability details in public issues.
