# Contributing

NIDDE uses strict verification-first development.

- No random implementation files.
- No silent architecture changes.
- No silent dependency/path changes.
- Follow the Manifest and Project Control.
- A blocked dependency blocks dependent work.
- New requirements require a Change Request.
- Never commit secrets.
- Implementation is not authorized until required architecture gates are completed.
