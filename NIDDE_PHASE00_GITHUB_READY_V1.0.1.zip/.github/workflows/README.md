CI/CD workflows are intentionally deferred until the CI/CD architecture gate is completed.
