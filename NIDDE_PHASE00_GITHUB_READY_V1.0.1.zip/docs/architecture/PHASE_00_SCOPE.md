# Phase 00 Scope

Allowed:
- Architecture decisions
- Manifest and control records
- Verification evidence
- Repository governance documentation

Locked:
- Backend implementation
- Database implementation
- Android implementation
- Admin implementation
- Production credentials
- Production deployment configuration

Next gate: AG-02 — Repository & System Architecture.
