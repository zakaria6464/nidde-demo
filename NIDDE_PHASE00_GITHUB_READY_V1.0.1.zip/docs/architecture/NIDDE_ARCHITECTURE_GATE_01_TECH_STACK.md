# NIDDE — ARCHITECTURE GATE 01
## Technology Stack Decision V1.0.2

**Phase:** 00 — ARCHITECTURE
**Status:** VERIFIED
**Application code:** NOT AUTHORIZED
**GitHub upload:** LOCKED

### 1. Decision

NIDDE will use a modular monolith backend, a PostgreSQL relational database, a single Android application with role-based experiences, a separate web Admin application, Redis for ephemeral/cache/queue workloads, object storage for user documents/media, REST/OpenAPI for primary API communication, and WebSockets for realtime features.

### 2. Backend

- Language: TypeScript
- Runtime: Node.js LTS
- Framework: NestJS
- Package manager: pnpm (workspace/package management)
- API style: REST
- API contract: OpenAPI
- Realtime: WebSocket gateway
- Validation: schema-based request validation at API boundaries
- Architecture: modular monolith with explicit domain modules and dependency boundaries
- Background work: queue-based workers using Redis-backed jobs

Reason: NestJS provides a structured, testable and modular server architecture and supports TypeScript, HTTP and WebSocket patterns suitable for NIDDE's domain-heavy backend.

### 3. Database

- Database: PostgreSQL
- ORM/data access: Prisma
- Migrations: version-controlled migrations
- Transactions: PostgreSQL transactions for financial/order state changes
- Constraints: foreign keys, unique constraints, check constraints and indexes are part of the data model
- Production database version: lock during infrastructure gate; do not guess a version now

PostgreSQL is selected because NIDDE requires transactional integrity, relational constraints, complex queries and strong consistency for orders, payments, KYC and permissions.

### 4. Cache / Jobs / Ephemeral State

- Redis
- Uses: cache, rate limiting support, short-lived state, job queues, idempotency support where appropriate
- Redis is NOT the source of truth for business records.

### 5. Android

- Language: Kotlin
- Build system: Gradle with Kotlin DSL
- UI: Jetpack Compose
- Architecture: UI + domain + data layers with unidirectional data flow
- State: ViewModel/StateFlow pattern where appropriate
- Networking: typed API client generated/maintained from the OpenAPI contract
- Local persistence: Room where offline/local persistence is required
- Background work: WorkManager where Android background execution is required
- Push: Firebase Cloud Messaging abstraction

The Android application remains one application package with role-specific navigation/features rather than three separately maintained applications, unless a later approved Change Request proves separation necessary.

### 6. Admin Web

- Framework: Next.js
- Language: TypeScript
- UI: React-based component architecture
- Package manager: pnpm
- API: same backend REST/OpenAPI contract
- Authentication: same centralized authorization model, with admin-specific permissions

### 7. Files / Media / KYC Documents

- Storage abstraction: S3-compatible object storage
- Database stores metadata, ownership, status and references; binary objects are not stored directly in PostgreSQL unless an explicit architecture decision requires it.
- Access: private objects with controlled, time-limited access URLs where appropriate.

### 8. External Integrations

Integrations must be hidden behind internal adapters/interfaces.

Initial integration categories:
- Maps/geocoding/routing
- Push notifications
- Email provider
- Payment provider(s)
- Object storage

No provider-specific implementation is locked in this gate unless separately approved. This prevents the core domain from becoming coupled to a vendor.

### 9. Authentication

- Central authentication service/module in the backend
- Short-lived access credentials
- Rotating refresh/session mechanism
- Passwords stored only as strong password hashes
- Role and permission checks enforced server-side
- Sensitive operations require explicit authorization checks
- Token/session revocation supported

Exact token/session storage and cryptographic parameters are locked in the Security Architecture Gate, not guessed here.

### 10. API Contract

REST/OpenAPI is the canonical external API contract.

Rules:
- Request/response schemas are versioned and validated.
- Error responses use a unified error model.
- Authentication/authorization requirements are documented per protected operation.
- Idempotency is required for operations where retries could create duplicate financial/order effects.

### 11. Payments

Payments use an internal payment domain with provider adapters.

The core domain must support:
- electronic payment
- Cash
- transaction lifecycle
- payment attempts
- refunds where supported
- provider callbacks/webhooks
- reconciliation
- provider payouts

No single payment provider is allowed to define the internal payment model.

### 12. Deployment

- Containerized services
- Separate development, test/staging and production environments
- Environment configuration separated from source
- Secrets supplied by secure environment/secret management
- CI/CD through GitHub Actions after repository foundation is locked

Exact cloud/provider selection is deferred to the Production Infrastructure Gate.

### 13. Testing Stack Direction

- Backend unit tests
- Backend integration tests against real PostgreSQL/Redis test services where required
- API contract tests
- Authentication/authorization tests
- Payment state-machine tests
- Critical-path end-to-end tests
- Android unit/instrumented/UI tests
- Security and dependency checks in CI

Exact test frameworks are locked during the Testing Architecture Gate.

### 14. Compatibility and Version Lock Boundary

Gate 01 locks technology families and package/build tooling. It does not freeze every dependency version. Version selection must pass compatibility verification before the exact physical-file manifest is locked.

### 15. Non-Decisions / Explicit Deferrals

The following are intentionally NOT locked yet:
- exact Node.js version
- exact Android compile/target SDK versions
- exact Kotlin/Compose versions
- exact Prisma version
- exact Redis version
- exact cloud provider
- exact map provider
- exact payment provider
- exact email provider
- exact object-storage vendor
- exact CI runner image

These require compatibility verification at their relevant gates and must not be guessed into the physical-file manifest.

### 15. Gate Acceptance Criteria

Gate 01 can be marked VERIFIED only if:
1. Every technology choice has a clear responsibility.
2. No core business domain is coupled directly to an external vendor.
3. The architecture supports Client, Artisan, Company and Admin roles.
4. PostgreSQL is the authoritative business-data store.
5. Redis is explicitly non-authoritative.
6. Payments support both Cash and electronic flows through an internal abstraction.
7. Android and Admin consume the same API contract.
8. Authentication and authorization are centralized server-side.
9. Exact dependency versions are deferred until compatibility/implementation gates.
10. No implementation code has been uploaded as part of this gate.

### 16. Status

**GATE 01 = VERIFIED**


## 17. Verification Evidence — 2026-08-18

AG-01 was checked against current official documentation. NestJS supports TypeScript and requires Node.js >=20; Node.js 24 is an LTS line; PostgreSQL 18 is the current supported major; Android guidance supports Jetpack Compose with unidirectional data flow, ViewModel and observable StateFlow; Next.js is an official React framework. Exact dependency versions remain deferred to the compatibility/version-lock gate.

Official evidence: citeturn0search2turn0search8turn0search9turn0search0turn0search1turn0search6turn0search5

**Result: PASS**
**AG-01 = VERIFIED**
**Implementation remains LOCKED.**
