# Security
Required production controls: server-side authorization, input validation, immutable audit events, rate limiting, anomaly detection, signed payment webhooks, no raw card storage, dispute/refund controls, secret management, dependency review, privacy minimization, and AI advisory-only limits.
AI must never be the sole authority for identity, payment authorization, permanent bans, legal conclusions or irreversible security actions.
Anti-scam signals include transaction value, trust, repeated patterns, off-platform payment/contact signals, insufficient detail, velocity and anomalies.
