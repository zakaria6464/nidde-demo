# Architecture
Domains: Identity/Roles, Marketplace, Requests, Offers, Matching, Payments, Trust/Reputation, Anti-Fraud, AI Assistance, Notifications, Disputes, Analytics/Reporting, Admin Governance, Audit/Security.

Rules: business logic must be separated from UI; sensitive authorization must be server-side in production; external providers must be adapters; sensitive events must be auditable; demo mode must work without secrets; production security decisions must fail closed.
