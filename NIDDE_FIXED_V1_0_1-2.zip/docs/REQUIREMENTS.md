# NIDDE Requirements Baseline
NIDDE is a multi-service marketplace with Customer, Worker and Admin roles. Required concepts: service categories, requests, offers, customer selection, execution lifecycle, Cash and In-App payment, trust/reputation, anti-fraud/anti-scam, AI assistance, Analytics/Reporting, KPI engine, notifications, disputes, audit trail, security and governance.
