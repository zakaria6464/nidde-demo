# NIDDE v1.1.0 — Visible UI Release

This release replaces the previous demo screen with a visibly redesigned NIDDE mobile experience.

## Visible changes
- New dark NIDDE header and branded home hero.
- Arabic/French bilingual presentation.
- Service category grid with 8 categories.
- Urgent-service CTA.
- Artisan profile and availability card.
- Client request modal and request lifecycle demo.
- Offer comparison and accept flow.
- Live-style tracking timeline after accepting an offer.
- Dedicated Artisan, Enterprise and Admin surfaces.
- Bottom navigation for Home / Requests / Messages / Profile.

## Important
This is a UI/flow release. Backend production integrations remain separate and must be connected before commercial production launch.
