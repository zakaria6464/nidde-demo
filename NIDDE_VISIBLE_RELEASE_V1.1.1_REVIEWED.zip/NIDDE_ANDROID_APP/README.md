# NIDDE Android — v1.1.0

Visible UI release built on the existing NIDDE Android/WebView shell.

The app now has a substantially redesigned mobile interface and a local demo flow so the change is immediately visible after installing the APK.

Build: `./gradlew assembleDebug` when Gradle/Android SDK are available.
