NIDDE V1.1.1 — reviewed build

- Visible client/worker/enterprise/admin demo UI is bundled directly in Android assets.
- Fixed GitHub Actions identity check to match versionCode 11.
- Android versionName bumped to 1.1.1.
- No backend files or previous reference files removed.
- APK is built from app/src/main/assets/index.html via the WebView MainActivity.
